loadstring(game:HttpGet("https://raw.githubusercontent.com/ssengigoog-commits/gc-motion-vfx-recorder/main/dist/GC_MotionVFX_Baker_v7_0_2.luau"))()
